<html>

					<link rel="stylesheet" type="text/css" href="bpcss/main.css" charset="utf-8" media="all">
					<link rel="stylesheet" type="text/css" href="bpcss/multiDate.css" charset="utf-8" media="all">
					<link rel="stylesheet" type="text/css" href="bpcss/lightbox.css" charset="utf-8" media="all">
					<link rel="stylesheet" type="text/css" href="bpcss/teaser_calendars.css">
					<meta http-equiv="content-type" content="text/html; charset=utf-8">
				
	


<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to TAHER HOTEL</title>
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<script type="text/javascript" src="xres/js/saslideshow.js"></script>
<script type="text/javascript" src="xres/js/slideshow.js"></script>
<script src="js/jquery-1.5.min.js" type="text/javascript" charset="utf-8"></script>
<script src="vallenato/vallenato.js" type="text/javascript" charset="utf-8"></script>
<link rel="stylesheet" href="vallenato/vallenato.css" type="text/css" media="screen" charset="utf-8">
<!--sa calendar-->	
		<script type="text/javascript" src="js/datepicker.js"></script>
        <link href="css/datepicker.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript">
		


		function makeTwoChars(inp) {
				return String(inp).length < 2 ? "0" + inp : inp;
		}

		function initialiseInputs() {
				// Clear any old values from the inputs (that might be cached by the browser after a page reload)
				document.getElementById("sd").value = "";
				document.getElementById("ed").value = "";

				// Add the onchange event handler to the start date input
				datePickerController.addEvent(document.getElementById("sd"), "change", setReservationDates);
		}

		var initAttempts = 0;

		function setReservationDates(e) {
				// Internet Explorer will not have created the datePickers yet so we poll the datePickerController Object using a setTimeout
				// until they become available (a maximum of ten times in case something has gone horribly wrong)

				try {
						var sd = datePickerController.getDatePicker("sd");
						var ed = datePickerController.getDatePicker("ed");
				} catch (err) {
						if(initAttempts++ < 10) setTimeout("setReservationDates()", 50);
						return;
				}

				// Check the value of the input is a date of the correct format
				var dt = datePickerController.dateFormat(this.value, sd.format.charAt(0) == "m");

				// If the input's value cannot be parsed as a valid date then return
				if(dt == 0) return;

				// At this stage we have a valid YYYYMMDD date

				// Grab the value set within the endDate input and parse it using the dateFormat method
				// N.B: The second parameter to the dateFormat function, if TRUE, tells the function to favour the m-d-y date format
				var edv = datePickerController.dateFormat(document.getElementById("ed").value, ed.format.charAt(0) == "m");

				// Set the low range of the second datePicker to be the date parsed from the first
				ed.setRangeLow( dt );
				
				// If theres a value already present within the end date input and it's smaller than the start date
				// then clear the end date value
				if(edv < dt) {
						document.getElementById("ed").value = "";
				}
		}

		function removeInputEvents() {
				// Remove the onchange event handler set within the function initialiseInputs
				datePickerController.removeEvent(document.getElementById("sd"), "change", setReservationDates);
		}

		datePickerController.addEvent(window, 'load', initialiseInputs);
		datePickerController.addEvent(window, 'unload', removeInputEvents);

		//]]>
		</script>
		<!--sa error trapping-->
		<script type="text/javascript">
		function validateForm()
		{
		var x=document.forms["index"]["start"].value;
		if (x==null || x=="")
		  {
		  alert("you must enter your check in Date(click the calendar icon)");
		  return false;
		  }
		var y=document.forms["index"]["end"].value;
		if (y==null || y=="")
		  {
		  alert("you must enter your check out Date(click the calendar icon)");
		  return false;
		  }
		}
		</script>
		<!--sa minus date-->
		<script type="text/javascript">
			// Error checking kept to a minimum for brevity
		 
			function setDifference(frm) {
			var dtElem1 = frm.elements['start'];
			var dtElem2 = frm.elements['end'];
			var resultElem = frm.elements['result'];
			 
		// Return if no such element exists
			if(!dtElem1 || !dtElem2 || !resultElem) {
		return;
			}
			 
			//assuming that the delimiter for dt time picker is a '/'.
			var x = dtElem1.value;
			var y = dtElem2.value;
			var arr1 = x.split('/');
			var arr2 = y.split('/');
			 
		// If any problem with input exists, return with an error msg
		if(!arr1 || !arr2 || arr1.length != 3 || arr2.length != 3) {
		resultElem.value = "Invalid Input";
		return;
			}
			 
		var dt1 = new Date();
		dt1.setFullYear(arr1[2], arr1[1], arr1[0]);
		var dt2 = new Date();
		dt2.setFullYear(arr2[2], arr2[1], arr2[0]);

		resultElem.value = (dt2.getTime() - dt1.getTime()) / (60 * 60 * 24 * 1000);
		}
		</script>
		<script type="text/javascript">
		$("#slideshow > div:gt(0)").hide();

		setInterval(function() { 
		  $('#slideshow > div:first')
			.fadeOut(1000)
			.next()
			.fadeIn(1000)
			.end()
			.appendTo('#slideshow');
		},  3000);
	</script>



	<!--Top Start -->
		<div class="top">

			<div id="logobar">
				<a class="main-logo" href="index.php"></a>
			</div>

			<div id="top-bar">

				<div class="inset">

					<nav style="float: right;" role="main">
						<a class="nav5" href="index.php">HOME </a><span class="divider">|</span>
						<a class="nav2" href="rooms.html">Rooms</a><span class="divider">|</span>
						<a class="nav10 last" href="location.php">Location</a><span class="divider">|</span>
						<a class="nav10 last" href="contactus.html">Contact Us</a><span class="divider">|</span>
                        <a class="nav10 last" href="admin.php">admin login</a>
					</nav>
                    
                        
				</div>

			</div>

		</div>
		<!--Top End -->


	
	
	
	
	<img style="  width: 100%; "  src="1.jpg" class="logo" >
	
	
	
 <div id="logo" style="left: 75%; height: auto; top: 30%; width: 260px; position: absolute; z-index:4;" >

					<h2 class="accordion-header" style="height: 18px; margin-bottom: 15px; color: rgb(255, 255, 255); background: none repeat scroll 0px 0px rgb(53, 48, 48);">Online Booking</h2>
					<div class="accordion-content" style="margin-bottom: 15px;">
						<form action="reservation/booking.php" method="post" style="padding-top: 4px;">
						<span style="margin-right: 11px;">Start Date: <input type="text" class="w8em format-d-m-y highlight-days-67 range-low-today" name="start" id="sd" value="" maxlength="10" readonly="readonly" style="width: 165px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;"/></span><br>
						<span style="margin-right: 11px;">End Date:<input type="text" class="w8em format-d-m-y highlight-days-67 range-low-today" name="end" id="ed" value="" maxlength="10" readonly="readonly" style="width: 165px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;" /></span><br>
						<input type="hidden" name="result" id="result" /><br>
						<span><input type="submit" onclick="setDifference(this.form);" value="CHECK AVAILABILITY" style="height: 34px; margin-left: 15px; width: 191px; padding: 5px; border: 3px double rgb(204, 204, 204);" /></span>
						
						</form>
					</div>

					<h2 class="accordion-header" style="height: 18px; margin-bottom: 15px; color: rgb(255, 255, 255); background: none repeat scroll 0px 0px rgb(53, 48, 48);">Cancel Resrvation</h2>
					<div class="accordion-content" style="margin-bottom: 15px;">
						<form action="cancelexec.php" method="post" style="margin-bottom:none;">
						<span style="margin-right: 11px;">Confirmation Number: <input type="text" name="confirmation" style="width: 165px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;"/></span><br><br>
						<input type="submit" id="submit" class="medium gray button" value="Proceed" style="height: 34px; margin-left: 15px; width: 191px; padding: 5px; border: 3px double rgb(204, 204, 204);" />
						</form>
					</div>
				</div>
	
	
	
	
	
	
	
	
    <link href="bpcss/style.css" rel="stylesheet" type="text/css">
    <link href="../panel1.bookingdirect.com/bd_booking_panel-v3/assests/css/think_web_booking.css" rel="stylesheet">
    <link href="../panel1.bookingdirect.com/bd_booking_panel-v3/assests/css/jquery-ui.css" rel="stylesheet">
     
    <script src="../code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <style>
        /*Booking Engine css */  
        #custom_engine {
            width: 100%;
            background-color: #033b4e;
            padding: 10px;
            box-sizing: border-box;
            float: left;
            position: fixed;
            bottom: 0;
            left: 0;
            z-index: 9999;
        }

        .booking_panel {
            max-width: calc(1250px - 88px);
            margin: 0 auto
        }

        #custom_engine .outer_booking #results_widget {
            width: 185px
        }

        #custom_engine .outer_booking .inputbox-be {
            width: 85px
        }

        #custom_engine .outer_booking input.login {
            background: #e7ae6f;
            text-shadow: none
        }

        #custom_engine p.booking-myaccount a {
            color: #d95809
        }

        #custom_engine .outer_booking #reservation_search {
            background: 0;
            padding: 0
        }

        #custom_engine .outer_booking {
            background: 0
        }

            #custom_engine .outer_booking p {
                height: auto
            }

            #custom_engine .outer_booking .calendar input {
                box-shadow: none
            }

            #custom_engine .outer_booking .room {
                box-shadow: none
            }

            #custom_engine .outer_booking #results_widget {
                box-shadow: none
            }

            #custom_engine .outer_booking .room {
                width: 108px
            }

        #custom_engine .outer_booking {
            color: #fff
        }

        #custom_engine p.booking-myaccount a {
            color: #fff !important;
            font-size: 12px;
        }

        #custom_engine .margin_top_p {
            margin-top: 34px !important
        }

        #custom_engine .outer_booking input.login {
            padding: 0 40px !important;
            background-color: #bdae73 !important;
            font-weight: normal
        }

        #custom_engine .outer_booking .room:before {
            right: 30px;
            border-top: #000 6px solid;
            border-left-width: 4px;
            border-right-width: 4px
        }

        #custom_engine .outer_booking #results_widget:before {
            border-top: #000 6px solid;
            border-left-width: 4px;
            border-right-width: 4px
        }

        #custom_engine .outer_booking .room:after {
            content: '';
            position: absolute;
            top: 8px;
            right: 10px;
            background: url(images/adults.jpg) no-repeat left top;
            width: 10px;
            height: 19px
        }

        #custom_engine .outer_booking .calendar input {
            background-image: url(images/calender.jpg)
        }

        #custom_engine .outer_booking p {
            padding: 7px 0
        }

        #custom_engine .outer_booking .fields-block, #custom_engine .outer_booking .fields-block-alter {
            text-align: left !important
        }

        #custom_engine .outer_booking p {
            display: block
        }

        #custom_engine .outer_booking #reservation_search > .fields-block-alter > .room:after {
            content: '';
            position: absolute;
            top: 9px;
            right: 12px;
            background: url(images/room.jpg) no-repeat left top;
            width: 11px;
            height: 19px
        }

        .outer_booking {
            font-family: 'QuicksandBook', sans-serif;
        }

        .find_title {
            display: none;
        }

        #custom_engine .outer_booking {
            float: none;
            max-width: 1000px;
            margin: 0 auto
        }

            #custom_engine .outer_booking p {
                margin: 0
            }

            #custom_engine .outer_booking .inputbox-be input {
                box-shadow: none;
                background-color: #ffffff;
                color: #666666;
            }

            #custom_engine .outer_booking .inputbox-be {
                width: 115px;
            }

            #custom_engine .outer_booking .child-popup .room {
                width: 65px;
                border: solid 1px #dadada;
            }

            #custom_engine .outer_booking .child-popup {
                color: #000000;
            }

        #adbox_widget .fields-block-alter {
        }

        #adbox_widget .child-popup {
            width: auto;
        }

        #adbox_widget .adbox-room-heading p {
            padding-top: 15px !important;
        }

        .head-line {
            background: #033b4e !important;
        }

        .ui-state-default {
            font-size: 12px;
        }

        .ui-datepicker .ui-datepicker-next, .ui-datepicker .ui-datepicker-prev {
            width: 1.8em;
            height: 1.8em;
        }

        #adbox_widget .adbox-item {
            float: left;
            width: 33%;
        }

            #adbox_widget .adbox-item .adbox-room-heading {
                width: 17%;
            }

            #adbox_widget .adbox-item .adbox-person {
            }

        .ui-datepicker .ui-datepicker-title {
            font-family: arial !important;
        }

        .age-head {
            font-size: 13px;
        }

        @media(min-width:768px) and (max-width:1024px) {
            #adbox_widget .adbox-item .adbox-room-heading {
                width: 25%;
            }

            #adbox_widget .adbox-item .adbox-person {
                width: 30%;
            }

            #adbox_widget .child-popup {
                width: 37%;
            }

            #adbox_widget .popup-age, .popup-age {
                width: 180px;
            }

                #adbox_widget .popup-age .child-popup, .popup-age .child-popup {
                    margin: 0 4%;
                    width: 38% !important;
                }
        }

        @media(max-width:767px) {
            #custom_engine {
                position: static;
            }

                #custom_engine .outer_booking .child-popup {
                    width: 38% !important;
                    padding: 0;
                }

                #custom_engine .popup-age {
                    width: 170px;
                }

                #custom_engine .age-head {
                    font-size: 14px;
                }

            #adbox_widget .adbox-item {
                width: 100%;
            }

            #adbox_widget .fields-block-alter {
                width: 27% !important;
            }
        }

        @media(max-width:767px) and (orientation:landscape) {
            #custom_engine .c_adult {
                width: 98px !important;
            }

            #custom_engine .fields-block-alter.width35pr, #custom_engine .fields-block-alter.width35pr.pdr10 {
                width: auto;
            }

            #adbox_widget .adbox-item {
                width: 46%;
            }

            #adbox_widget .fields-block-alter {
                width: 29% !important;
            }
        }
        /*Booking Engine css */
    </style>

		
		<div id="custom_engine">
            

        </div>
 	
		
		<div id="locationbx"></div>

		

			<div class="subheader">
			<div class="subheaderbx">

				<!--Control Bar-->
				<div id="controls-wrapper" class="load-item">
					<div id="controls">
						<ul id="slide-list"></ul>
					</div>
				</div>

       
     
	<img src="bpimages/followus.jpg" class="followus">

				<a href="https://www.facebook.com/taher2011" target="blank" class="facebook"><div class="fblink"></div></a>
				<a href="https://twitter.com/" target="blank" class="twitter"><div class="twitterlink"></div></a>
			</div>
		</div>



		<div class="maincontent">
			<div class="mainbkrndbx">
				<div class="maincopyleft">
					<a name="content"></a>
					<div id="content"></div>

					<div class="bebackground">
					

	<h1>Taher Hotel</h1>

	<p>our story started on 2019 from FTMK of UTeM, designed by ENG <a href="https://www.facebook.com/taher2011">Taher Al-fakih</a> under Dr/Maslita ”.</p>

	<p>Within our artfully decorated hotel, you'll find a host of comforts and amenities, including complimentary Wi-Fi, coffees, teas, juices, and sodas, along with plush bedding,  .  With an incredible location, top amenities and a friendly, accommodating staff, Taher Hotel is the premier hotel for any occasion in Malaysia-Melaka City.</p>

		<!-- Preload thumbnails -->
		<img src="bpimages/headers/home/thumbs/Home_01.jpg" width="0">
		<img src="bpimages/headers/home/thumbs/Home_02.jpg" width="0">
		<img src="bpimages/headers/home/thumbs/Home_03.jpg" width="0">
		<img src="bpimages/headers/home/thumbs/Home_04.jpg" width="0">


					
					</div>

				<div class="clearfix"></div>
				</div>

			</div>
		</div>

		<div class="clearfix"></div>
		
		<div class="clearfix"></div>


		

		<footer>
			<div class="inset">
				
		<a href="#top"><img src="bpimages/top.png" class="totop"></a>

		<script>
			$(document).ready(function(){
			  $("a[href='#top']").click(function() {
				  $("html, body").animate({ scrollTop: 0 }, "slow");
				  return false;
				});
			});
		</script>


				<div class="footer-address">
					<div class="footer-nav">
						<a class="fnav1" href="https://www.facebook.com/taher2011">Contact</a><span>|</span>
						
					</div>

			<address><span itemprop="name">TAHER HOTEL</span>
			<h1>01161807743 &bull; <a href="">BBU, Melaka City, Malacca, 75350,Malaysia  </a></h1>
		<p>Working Hours&nbsp;&nbsp;&bull;&nbsp;&nbsp;Hotel guest check-ins available daily 24 hours.</p>
		
		<p>&copy; Copyright 2019 TAHER | All Rights Reserved <br /></p>
        
			</div>

			</div>

			

			<div class="clear"></div>

			
	</footer>

		
		
</body></html>
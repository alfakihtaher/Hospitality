// Copyright 2013 Open Hospitality. All Rights Reserved.
// No conflict with other $-libraries on page
(function (window, $) {

function CalendarMonth(month, year, parentCalendar, index) {
    var currMonth = month,
        currYear = year,
        nextMonth = currMonth === 11 ? 0 : currMonth + 1,
        nextYear = currMonth === 11 ? currYear + 1 : currYear;

    this.index = index;
    this.parent = parentCalendar;
    this.useTables = this.parent.useTables;
    this.startingDate = this.parent.startingDate;
    this.month = currMonth;
    this.year = currYear;
    this.firstDay = new Date(currYear, currMonth, 1);
    this.startingDay = new Date(currYear, currMonth, 1).getDay();
    this.daysInMonth = new Date((new Date(nextYear, nextMonth, 1).getTime() - 86400000)).getDate();
}

CalendarMonth.prototype = {
    createTeaserHeader: function () {
        var cal_months_labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
            html = '<div id="teaserHeader">';

        html += (this.index === 0) ? '<div id="prevMonth" class="headerCol pdarrows left disabled"></div>'
                                   : '<div id="prevMonth" class="headerCol pdarrows left"></div>';
        html += '<div class="headerCol headerMonth"><a id="inline" href="#data">' + cal_months_labels[this.month] + "&nbsp;" + this.year + '</a></div>';
        html += (this.index + 1 < this.parent.monthCount) ? '<div id="nextMonth" class="headerCol pdarrows right"></div>'
                                                        : '<div id="nextMonth" class="headerCol right">&nbsp;</div>';
        html += '</div>';

        return html;
    },
    createDaysOfWeek: function () {
        var cal_days_labels = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
            html = (this.useTables === true) ? '<tr>' : '<div class="row ">';

        for (var i = 0; i <= 6; i++) {
            html += (this.useTables === true) ? '<td class="dateCol">' : '<div class="dateCol">';
            html += cal_days_labels[i];
            html += (this.useTables === true) ? '</td>' : '</div>';
        }

        html += (this.useTables === true) ? '</tr>' : '</div>';

        return html;
    },
    renderDayOutOfRange: function (dt, calMonth) {
        return this.useTables === true ? '<td class="col disabled">' + dt.getDate() + '</td>' : '<div class="col disabled">' + dt.getDate() + '</div>'
    },
    getDailyCss: function (dt, calMonth) {
        var today = Utils.stripTime(new Date()),
            dtSt = Utils.stripTime(dt),
            cssClasses = 'col ',
            dateAsYYYYMMDD = Utils.dateToYYYYMMDD(dtSt),
            notAvailable = ($.inArray(dateAsYYYYMMDD, this.parent.unavailableDates) >= 0),
            isDisabled = false,
            isCurrentDate = false,
            isAvailable = false,
            isPrevSelected = false,
            isSelected = false,
            hotelDate = this.parent.hotelDate;

        if (this.parent.highlightedDate !== undefined) {
            if (dt.getTime() === this.parent.highlightedDate.getTime()) {
                isPrevSelected = true;
            }
        }

        if (dt.getTime() < this.parent.firstSelectableDate.getTime()) {
            isDisabled = true;
        }

        if (notAvailable) {
            isDisabled = true; //cssClasses += 'disabled '
        } else {
            if (dt.getTime() >= hotelDate.getTime()) {
                isAvailable = true; //cssClasses += 'available '
            } else {
                isDisabled = true; //cssClasses += 'disabled '
            };
        }

        if (this.parent.selectedDate.getTime() === dt.getTime()) {
            isSelected = true; //cssClasses += 'selected '
        }

        if ((isPrevSelected === true) && (isDisabled === true)) {
            isDisabled = false;
            cssClasses += 'prevSelected ';
        }

        if (isDisabled === true) {
            cssClasses += 'disabled ';
        }

        if (isAvailable === true) {
            cssClasses += 'available ';
        }

        if (isSelected === true) {
            cssClasses += 'selected ';
        }

        if (isCurrentDate === true) {
            cssClasses += 'currentDay ';
        }

        return cssClasses;
    },
    renderDayInRange: function (dt, calMonth) {
        var today = Utils.stripTime(new Date()),
            tags = (this.useTables === true) ? { open: '<td ', close: '</td>'} : { open: '<div ', close: '</div>'},
            html = tags.open + 'id="d' + Utils.dateToYYYYMMDD(dt) + '" class="' + this.getDailyCss(dt, calMonth) + '">' + dt.getDate() + tags.close;

        return html;
    },
    isInRange: function (day, weekNbr, dayOfWeek) {
        return (day <= this.daysInMonth && (weekNbr > 0 || dayOfWeek >= this.startingDay));
    },
    generateHTML: function () {
        var day = 1,
            offset = this.startingDay,
            html = '<div id="teaserWrapper">' + this.createTeaserHeader();

        html += (this.useTables === true) ? '<table id="teaserboxCalendar">' + this.createDaysOfWeek() + '<tr class="row">'
                                          : '<div id="teaserboxCalendar">' + this.createDaysOfWeek() + '<div class="row">';
        
        for (var weekNbr = 0; weekNbr < 9; weekNbr++) {
            for (var dayOfWeek = 0; dayOfWeek <= 6; dayOfWeek++) {
                var inRange = this.isInRange(day, weekNbr, dayOfWeek);
                var dt = new Date(this.year, this.month, day, TB.hotelDate.getHours(), TB.hotelDate.getMinutes(), TB.hotelDate.getSeconds());

                if (inRange) {
                    html += this.renderDayInRange(dt, this);
                    day++
                } else {
                    dt = new Date(dt.getTime() - (86400000 * offset)); 
                    html += this.renderDayOutOfRange(dt, this);
                    offset = offset - 1;
                };
            }
            // stop making rows if we've run out of days
            if (day > this.daysInMonth) {
                break;
            } else {
                html += (this.useTables === true) ? '</tr><tr class="row">' : '</div><div class="row">';
            }
        }
        
        html += (this.useTables === true) ? '</table>' : '</div>';  // teaserboxCalendar
        html += '<div id="teaser-close">Close</div>'; // close teaser
        html += '</div>'; // teaserWrapper

        return html;
    }
};

function Calendar(options) {
    this.unavailableDates = options.unavailableDates || [];
    this.useTables = options.useTables || false;
    this.monthCount = options.monthCount || 24;
    this.startingDate = options.startingDate || Utils.stripTime(new Date());
    this.dateLabel = options.dateLabel;
    this.container = options.container;
    this.currentIndex = 0;
    this.selectedDate = this.startingDate;
    this.hotelDate = options.hotelDate;

    if (options.checkInLabel === '') {
        this.updateDateLabel(this.startingDate);
    };
};

Calendar.prototype = {
    monthNames: ['January','February','March','April','May','June','July','August','September','October','November','December'],
    activate: function(activationOptions) { 
        var dbTime = +new Date();

        this.firstSelectableDate = activationOptions.firstSelectableDate;
        this.calendars = this._createCalendars();

        var that = this;
        if (activationOptions.selectedDate !== undefined) {
            this.selectedDate = activationOptions.selectedDate;
            var idx = this._getCalendarIndexForDate(activationOptions.selectedDate);

            this.currentIndex = idx > -1 ? idx : 0;
        }

        // Open Effect Starts
        $(document.body).off('click.teaser');
        this.container.empty();

        var calendarMarkup = this.calendars[this.currentIndex].generateHTML();
        this.container.append(calendarMarkup).hide().slideToggle(1000);
        // Open Effect Ends

        this.render();
    },
    render: function() {
        $(document.body).off('click.teaser');
        this.container.empty();

        var calendarMarkup = this.calendars[this.currentIndex].generateHTML();
        this.container.append(calendarMarkup);
        var that = this;
        
        $(document.body).on('click.teaser', function(e) {
            if (e.target.id === 'nextMonth') {
                Utils.stopEvent(e);
                that.next();

                return false;
            };

            if (e.target.id === 'prevMonth') {
                Utils.stopEvent(e);
                that.prev();

                return false;
            }

            var isValid = $(e.target).hasClass('available');

            if (isValid === true) {
                var yr_mnth_dy = e.target.id.substr(1,8),
                    inYear = parseInt(yr_mnth_dy.substr(0, 4), 10),
                    inMonth = parseInt(yr_mnth_dy.substr(4, 2), 10) - 1,
                    inDay = parseInt(yr_mnth_dy.substr(6, 2), 10),
                    selectedDate = new Date(inYear, inMonth, inDay, TB.hotelDate.getHours(), TB.hotelDate.getMinutes(), TB.hotelDate.getSeconds());

                that.selectedDate = selectedDate;
                that.destroy();
                that.updateDateLabel(selectedDate);
                $(that).trigger('DateChanged', [selectedDate, e.target.id]);
            } else {
                that.destroy();
            }

            return false;
        });
    },
    _createCalendars: function() {
        var currMonth = this.startingDate.getMonth(),
            currYear = this.startingDate.getFullYear(),
            monthYears = [];

        for (var i = 1; i <= this.monthCount; i++) {
            monthYears.push(new CalendarMonth(currMonth, currYear, this, i-1));
            currMonth += 1;

            if (currMonth === 12) {
                currMonth = 0;
                currYear += 1;
            };
        };
        return monthYears;
    },
    _getCalendarIndexForDate: function(dt) {
        var monthCount = this.calendars.length - 1,
            foundIndex = -1;

        for (var i = 0; i <= monthCount; i++) {
            if (this.calendars[i].year === dt.getFullYear() && this.calendars[i].month === dt.getMonth()) {
                foundIndex = i;
                break;
            }
        }
        return foundIndex;
    },  
    first: function() {
        this.currentIndex = 0;
        this.render();
    },
    next: function() {
        this.currentIndex = (this.currentIndex + 1) < this.calendars.length ? this.currentIndex + 1 : this.calendars.length - 1;        
        this.render();
    },
    prev: function() {
        this.currentIndex = this.currentIndex > 0 ? this.currentIndex - 1 : 0;        
        this.render();
    },
    destroy: function() {
        // Close Effect
        this.container.delay(300).animate({'height': 'toggle'}, 1000, function () {$(this).empty()});
        $(document).off('keydown.teaser');
        $(document.body).off('click.teaser');       
    },
    updateDateLabel: function(dt) {
        $("input[name=pdcheckinyyyymmdd]").val(Utils.dateToYYYYMMDD(TB.inDateCal.selectedDate));
        $("input[name=pdcheckoutyyyymmdd]").val(Utils.dateToYYYYMMDD(TB.outDateCal.selectedDate));
        // DM - Updates calendar label in MM/DD/YYYY format
        this.dateLabel.flex_label.val((dt.getMonth() + 1).toString() + '/' + Utils.padZero(dt.getDate().toString(), 2) + '/' + dt.getFullYear().toString());
        // DM - Updates calendar label in Month Date, Year format
        // this.dateLabel.flex_label.val(this.monthNames[dt.getMonth()] + ' ' + Utils.padZero(dt.getDate().toString(), 2) + ', ' + dt.getFullYear().toString());
    }
}

$.fn.Teaserbox = function(options) {
    TB = {};
    var defaultSettings = {
        DefaultStayLength: 1,
        MaxLengthStay: 30,
        belink: "https://www.reservations-page.com/c00000/h00000/ov.aspx",
        RoomsPage: "rooms",
        NraPage: "nra",
        vl: options.vl,
        chaincode: options.chaincode,
        hotelcode: options.hotelcode,
        hotelID: options.hotelID,
        chaninID: options.chainid,
        utcOffset: 0, // Hotel's UTC Offset
        hourCutoff: 24, // Cutoff hour for current day bookings in 24hr time
        checkInLabel: '', // {string} label value i.e. 'Check-In'
        checkOutLabel: '' // {string} label value i.e. 'Check-Out'
    };

    TB.Settings = $.extend(defaultSettings, options);

    TB.hotelDate = (function(utcOffset, hourCutoff) {
        var thisdate = new Date(),
            utcTime = new Date(thisdate.getUTCFullYear(), thisdate.getUTCMonth(), thisdate.getUTCDate(), thisdate.getUTCHours() + utcOffset, thisdate.getUTCMinutes(), thisdate.getUTCSeconds());

        // Date + hourCutoff
        // If current hour is larger/equal to hourCutoff, set day to the next day (utcTime.getHours() + 24)
        if (utcTime.getHours() >= hourCutoff) {
            utcTime = new Date(utcTime.getFullYear(), utcTime.getMonth(), utcTime.getDate(), utcTime.getHours() + 24, utcTime.getMinutes(), utcTime.getSeconds())
        }

        return utcTime;	
    })(TB.Settings.utcOffset, TB.Settings.hourCutoff);

    TB.inDateOptions = {
        container: $('#inDateContainer'),
        dateLabel: {flex_label: $("#inDate")}, // ID of Check-In <input/> or <div> that initializes the calendar 
        useTables: true,
        startingDate: TB.hotelDate,
        label: TB.Settings.checkInLabel,
        hotelDate: TB.hotelDate
    };

    TB.outDateOptions = {
        container: $('#outDateContainer'),
        dateLabel: {flex_label: $("#outDate")}, // ID of Check-Out <input/> or <div> that initializes the calendar
        useTables: true,
        startingDate: Utils.addDays(TB.inDateOptions.startingDate, 1),
        label: TB.Settings.checkOutLabel,
        hotelDate: TB.hotelDate
    };

    TB.inDateCal = new Calendar(TB.inDateOptions);
    TB.outDateCal = new Calendar(TB.outDateOptions);

    $(TB.inDateCal).bind('DateChanged', function (event, dateValue, sourceid) {
        TB.outDateCal.startingDate = Utils.addDays(dateValue, 1);
        TB.outDateCal.highlightedDate = dateValue;        
        TB.outDateCal.selectedDate = TB.outDateCal.startingDate;        
        TB.outDateCal.updateDateLabel(TB.outDateCal.startingDate);
    });

    // If selected check-out date is smaller than check-in date
    $(TB.outDateCal).bind('DateChanged', function (event, dateValue, sourceid) {
        if (TB.outDateCal.selectedDate < TB.inDateCal.selectedDate) {
            alert('Check Out date cannot be before Check In date. Please select another date.');
            TB.outDateCal.selectedDate = Utils.addDays(TB.inDateCal.selectedDate, 1);
            TB.outDateCal.updateDateLabel(TB.outDateCal.startingDate);
        }
    });

    $("#inDate").on('click', function (e) {
        Utils.stopEvent(e);
        TB.outDateCal.destroy();

        var activationOptions = { selectedDate: TB.inDateCal.selectedDate, firstSelectableDate: TB.inDateCal.startingDate};

        TB.inDateCal.activate(activationOptions);

        return false;
    });

    $("#outDate").on('click', function (e) {
        Utils.stopEvent(e);
        TB.inDateCal.destroy();

        var activationOptions = {
            firstSelectableDate: TB.outDateCal.startingDate,
            lastSelectableDate: Utils.addDays(TB.outDateCal.startingDate, 30)
        };

        TB.outDateCal.activate(activationOptions);

        return false;
    });

    TB.SubmitElement = $('#teaser-submit');

    TB.SubmitElement.click(function () {
        var baseUrl = TB.Settings.belink,
            request = baseUrl + '?',
            $promo = $('#pdpromocode'),
            $roomcount = $('#pdrooms'),
            $checkinval = $('#pdcheckinyyyymmdd').val(),
            $checkoutval = $('#pdcheckoutyyyymmdd').val(),
            toInteger = function (value, defaultValue) {
                var val = (value === '') ? defaultValue : value;

                return !isNaN(val) ? Number(val) : defaultValue;
            },
            $adults = toInteger($('#pdadults').val(), 1),
            $children = toInteger($('#pdchildren').val(), 0);

            // checkin=20141010&checkout=20141012&occupancy=1-0&promocode=BAR

            request += 'checkin=' + $checkinval;
            request += '&checkout=' + $checkoutval;
            request += '&occupancy=' + $adults + '-' + $children;

        // request += 'psk801=psk801&cmd=post';
        // request += '&pdcheckinyyyymmdd=' + Utils.dateToYYYYMMDD(TB.inDateCal.selectedDate);
        // request += '&pdcheckoutyyyymmdd=' + Utils.dateToYYYYMMDD(TB.outDateCal.selectedDate);
        // request += '&pdadults=' + $adults;
        // request += '&pdchildren=' + $children;
        // request += '&__roomspage=' + TB.Settings.RoomsPage;

        if ($checkinval === '') {
            alert('Please select Check In date');

            return false;
        };

        if (TB.Settings.NraPage !== '') {
            request += '&__nrapage=' + TB.Settings.NraPage;
        };

        if ($promo.length === 1 && $promo.val() != 'Promo Code') {
            request += '&pdpromocode=' + $promo.val();
        }

        if ($roomcount.length === 1) {
            request += '&pdrooms=' + $roomcount.val();

            if ($roomcount.val() > 1) {
                request += '&multiroomversion=1';
            }
        }

        if (TB.Settings.vl !== '') {
            request += '&vl=' + TB.Settings.vl; 
        }

        location.href = request;

        return false;
    });
};

// Fix placeholder in IE
var placeholderFix = function () {
    if(!$.support.placeholder) { 
        var active = document.activeElement;

        $(':text, textarea').focus(function () {
            if ($(this).attr('placeholder') != '' && $(this).val() == $(this).attr('placeholder')) {
                $(this).val('').removeClass('hasPlaceholder');
            }
        }).blur(function () {
            if ($(this).attr('placeholder') != '' && ($(this).val() == '' || $(this).val() == $(this).attr('placeholder'))) {
                $(this).val($(this).attr('placeholder')).addClass('hasPlaceholder');
            }
        });
        $(':text').blur();
        $(active).focus();
        $('form').submit(function () {
            $(this).find('.hasPlaceholder').each(function () {$(this).val(''); });
        });
    }
};

var multiroomDD = function () {
    var $occupancy = $('#pdadults, #pdchildren'),
        rooms = $('#pdrooms');

    rooms.on('change', function (e) {(rooms.val() == 1) ? $occupancy.show() : $occupancy.hide()});
};

$(document).ready(function () {
    // placeholderFix();
    multiroomDD();
});

}) (window, window.jQuery);
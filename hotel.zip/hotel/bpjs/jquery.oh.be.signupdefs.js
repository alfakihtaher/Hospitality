/* Copyright 2009 Open Hospitality, Inc.  All rights reserved. */
$(document).ready(function() {
    new DropdownSignup("#SUFS", ".ssemail", "top", "slide", true); 
    /*new LightboxSignup("#spiffy_signup", ".sspopup", "center", "fade", true); */
	/* new LightboxSignup("#spiffy_signup", "#sspopup2", "center", "fade", true); */
});

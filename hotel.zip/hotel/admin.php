
<?php
  //Connect to mysqli server
  include "connect.php";

$db_host   = 'localhost';
$db_user    = 'root';
$db_pass    = '';
$db_database  = 'shoopingcart'; 

/* End config */


$connection = mysqli_connect($db_host, $db_user, $db_pass, $db_database) or die('Unable to establish a DB connection');

  if (isset($_POST['login'])){




    $user = isset($_POST['user']) ? $_POST['user'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
  
    $stmt = mysqli_query($connection, "SELECT * FROM user WHERE name = '$user' AND password = '$password'");

    $check =  mysqli_num_rows($stmt);

    if($check > 0){

      while($result = mysqli_fetch_assoc($stmt)){

      //Login Successfuly
      session_start();
      // session_regenerate_id();
      // $member = mysql_fetch_assoc($result);
      $_SESSION['SESS_MEMBER_ID'] = $result['user_id'];
      $_SESSION['SESS_POSATION_NAME'] = $result['position'];
      
      header("location: admin/dashboard.php");
      exit();

      }

    } else {

      //Login failed
      header("location: index.php");
      exit();

    }

  }

?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: grey;
  font-size: 18px;
}

button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

a {
  text-decoration: none;
  font-size: 22px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.7;
}
</style>
</head>
<body>


<div class="card">
  <img src="admin.jpg" alt="taher" style="width:100%">
  <h1>TAHER</h1>
  <p class="title">web designer </p>
 
          <div class="accordion-content" style="margin-bottom: 15px;">
            <form method="POST" action="" style="margin-bottom:none;">
            <!-- <form action="" method="post" style="margin-bottom:none;"> -->
            <span style="margin-right: 11px;"><input type="text" name="user" placeholder="Username" style="width: 165px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;"/></span><br>
            <span style="margin-right: 11px;"><input type="password" name="password" placeholder="Password" style="width: 165px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;"/></span><br><br>
            <input type="submit" id="submit" value="login" name="login" style="height: 34px; margin-left: 15px; width: 191px; padding: 5px; border: 3px double rgb(204, 204, 204);" />
            </form>
            <br></br>
          </div>
</div>

</body>
</html>

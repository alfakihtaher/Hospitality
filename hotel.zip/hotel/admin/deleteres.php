<?php

// This is a sample code in case you wish to check the username from a mysql db table
include 'connect.php';
if($_GET['id'])
{
$id=$_GET['id'];
 mysqli_query($connection, "delete from reservation where confirmation='$id'");
 mysqli_query($connection, "delete from roominventory where confirmation='$id'";

}

?>